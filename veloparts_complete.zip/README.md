# VeloParts — Full Project (Example)

This archive contains a full example project for a bicycle parts ecommerce site:
- backend: Node + Express + Mongo + Stripe skeleton
- static frontend: HTML/CSS/JS that talks to the backend
- scripts to seed a product catalog (All-Mountain / Gravel / City / BMX / Maintenance)
- Docker compose example
- .env.example files for configuration

**How to run (locally / Codespace)**

1. Start MongoDB (Docker or Atlas). Example with Docker:
   ```
   docker run -d -p 27017:27017 --name mongo mongo:6
   ```

2. Backend:
   ```
   cd backend
   npm install
   cp .env.example .env
   # edit .env if needed
   node scripts/init.mjs   # seed products (optional)
   npm run dev
   ```

3. Frontend:
   ```
   cd frontend
   # static server (for dev) - using npm package 'serve' or open index.html in browser
   npx serve -l 3000 .
   ```

This project is an example scaffold. Replace environment variables and Stripe keys before using in production.
